﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FShredder.Bll.Utils;
using System.IO;


namespace FileShredder
{
    class Program
    {

        static void Main(string[] args)
        {
            //var drives = DriveInfo.GetDrives();
            //var drivesName = drives.Select(x => x.Name).ToArray();

           var data =  FShredder.Bll.Abstractions.XmlParser.Parse(@"C:\Users\r.ershov\source\repos\FileShredder\FileShredder\DataTest.xml");
            var dir = data[0];
            data.RemoveAt(0);
            var fileEngine = new FileEngine();
            fileEngine.RemoveFiles(dir, data);



           //var result =  engine.ShowAllFiles(drivesName, new[] {"" });
           // foreach(var file in result)
           // {
           //     Console.WriteLine(file.ToString());
           // }

            Console.ReadKey();
        }
    }
}
