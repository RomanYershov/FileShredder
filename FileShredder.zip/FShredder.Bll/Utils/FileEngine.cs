﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using FShredder.Bll.Abstractions;
using System.IO;

namespace FShredder.Bll.Utils
{
    public class FileEngine : IService
    {
        
        public IEnumerable ShowAllFiles(string[] drives, string[] files)
        {
            Queue<string> queue = new Queue<string>();
            foreach (var rootDir in drives)
            {
                queue.Enqueue(rootDir);
                while (queue.Count > 0)
                {
                    var currentDir = queue.Dequeue();
                    string[] childDirectories;
                    try
                    {
                        childDirectories = Directory.GetDirectories(currentDir);
                    }
                    catch(Exception ex)
                    {
                        continue;
                    }
                    var innerFiles = Directory.GetFiles(currentDir);
                    foreach(var file in innerFiles)
                    {
                        yield return file;
                    }
                    foreach (var nextDir in childDirectories)
                    {
                        queue.Enqueue(nextDir);
                    }
                }
            }
           yield return "End";
        }

        public void RemoveFiles(string dirPath, List<string> files)
        {
            int count = 0;
            DirectoryInfo dirInfo = new DirectoryInfo(dirPath);
            var innerFiles = dirInfo.GetFiles();
            foreach(var file in innerFiles)
            {
                try
                {
                    if(!files.Contains(file.Name))
                    {
                        file.Delete();
                        Logger.Info($"Удален файл {file.Name}");
                        ++count;
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Ошибка удалениея файла {file.Name}",ex);
                    continue;
                }
            }
            Logger.Info($"Всего удалено ({count}) файлов") ;
        }

        public IEnumerable<string> GetFiles(string dir, string[] ignoreFiles)
        {
            var innerFiles = Directory.GetFiles(dir);
            return innerFiles;
        }


        private string GetNameFromPath(string path)
        {
            var resArr = path.Split('\\');
            var name = resArr[resArr.Length - 1];
            return name;
            
        }

      
    }
}
