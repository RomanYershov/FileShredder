﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace FShredder.Bll.Abstractions
{
    public class XmlParser
    {
        public static List<string> Parse(string path)
        {
            List<string> resultList = new List<string>();
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(path);

            var el = xDoc.DocumentElement;
            foreach(XmlNode node in el)
            {
                resultList.AddRange(GetAttribute(node));
            }
            return resultList;
        }

        private static List<string> GetAttribute(XmlNode node)
        {
            List<string> result = new List<string>();
            if(node.Attributes.Count > 0)
            {
                foreach(XmlAttribute attr in node.Attributes)
                {
                    result.Add(attr.Value);
                }
            }
            foreach(XmlNode childNode in node.ChildNodes)
            {
               result.AddRange(GetAttribute(childNode));
            }
            return result;
        }
    }
}
